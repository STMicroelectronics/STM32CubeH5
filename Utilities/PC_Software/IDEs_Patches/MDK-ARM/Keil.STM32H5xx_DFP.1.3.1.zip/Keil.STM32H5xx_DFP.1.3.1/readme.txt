**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32H5 devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ****************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32H5
  devices by MDK-ARM v5.34 and laters.
  
  We nform you that this package is suitable for internal & external use.
  
  Running the "Keil.STM32H5xx_DFP.1.3.1.pack" adds the following:
  ==============================================================
  1. Part numbers with 2MB Flash size: STM32H562xIxx / STM32H563xIxx / STM32H573xIxx
  2. Part numbers with 1MB Flash size: STM32H562xGxx / STM32H563xGxx
  3. Part numbers with 512KB Flash size: STM32H523xExx / STM32H533xExx   
  4. Part numbers with 256KB Flash size: STM32H523xCxx.
  5. Product line with 128kB Flash size:STM32H503xBxx

  6. Automatic STM32H5 flash algorithm selection.

  7. STM32H573, STM32H563, STM32H562 & STM32H03 SVD files v1r1.
	 STM32H523 & STM32H533 SVD file v0r1.


  How to use:
  ==========
 * Before installing the files mentioned above, you need to have MDK-ARM v5.34 or later installed. 
   You can download pack from keil web site @ www.keil.com
 
 * Double Clic on  "Keil.STM32H5xx_DFP.1.3.0.pack" in order to install this pack in 
   the Keil install directory.

 SVD files ReleaseNotes:
 =======================
	=======================================================
	STM32573_v1r0:     initial release
	=======================================================
	First release: adding support to STM32H573 devices 
	=======================================================
	STM32573_v1r1:     seconde release
	=======================================================
	Clean up & Adding support for I2C3/I2C4

	=======================================================
	STM32563_v1r0:     initial release
	=======================================================
	First release: adding support to STM32H563 devices 
	=======================================================
	STM32563_v1r1:     seconde release
	=======================================================
	Clean up & Adding support for I2C3/I2C4
	
	=======================================================
	STM32562_v1r0:     initial release
	=======================================================
	First release: adding support to STM32H562 devices 
	=======================================================
	STM32562_v1r1:     seconde release
	=======================================================
	Clean up & Adding support for I2C3/I2C4
	
	=======================================================
	STM32503_v1r0:     initial release
	=======================================================
	First release: adding support to STM32H503 devices 
	=======================================================
	STM32503_v1r1:     seconde release
	=======================================================
	Clean up & Adding support for I2C3/I2C4
	
	=======================================================
	STM32H523_v0r1:    initial release
	=======================================================
	Doc ID: RM0510 - Rev 0.2 - 25 September 2023
	First release based on IPxact delivery
	(derived from STM32H5-2M) without PKA/AES/SAES
		
	=======================================================
	STM32H533_v0r1:    initial release
	=======================================================
	Doc ID: RM0510 - Rev 0.2 - 25 September 2023
	First release based on IPxact delivery
	(derived from STM32H5-2M) with PKA/AES/SAES






	



