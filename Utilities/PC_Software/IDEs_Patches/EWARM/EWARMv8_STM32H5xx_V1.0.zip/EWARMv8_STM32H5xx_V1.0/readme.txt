**
  *************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32H5x devices support on EWARM.
  *************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32H5xx 
  devices by EWARM8 and laters.

  1. If you have already installed an STM32H5 patch before, you can remove it by running 
  Uninstall_Patch.bat (run as administrator).

  2. Running the "EWARMv8_STM32H5xx_V1.0.exe" adds the following: 
  ================================================================ 
    - Product line with 2MB Flash size:STM32H563xI/H573xI/H562xI.
    - Product line with 1MB Flash size:STM32H563xG/H562xG.
    - Product line with 128kB Flash size:STM32H503xB.
    - Automatic STM32H5 2M Internal Secure and Non-secure Flash algorithm selection.
    - Automatic STM32H5 1M Internal Secure and Non-secure Flash algorithm selection.
    - Automatic STM32H5 128K Internal Non-secure Flash algorithm selection.
    - STM32H573I-DK dedicated connection with OSPI external loader support.
    - files (.mac, .boards, .flash) for secure flashloader when life state code in TZ-Clozed or iROT-provisioned.
    - STM32H5 2MB and H503 128KB SVD files.

PS: when using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32H5xx_V1.0.exe"  as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \". 

 * When the device is in TZ-closed or iROT-provisioned life state, It's recommended to use FlashSTM32H5_SEC.board as flashloader:
	-Go to "Options->Debugger->Download".
	-Check "Override default .board file".
	-Browse and select "FlashSTM32H5_SEC.board" under "IAR_INSTALL_FOLDER->arm->config->flashloader->ST".

Known Limitation:
================
 * When the device is in TZ-closed or iROT-provisioned life state, You can debug only with software reset. 





	



