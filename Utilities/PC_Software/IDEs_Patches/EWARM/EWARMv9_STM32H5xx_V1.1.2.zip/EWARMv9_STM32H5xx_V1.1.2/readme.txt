**
  *************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32H5 devices support on EWARM.
  *************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  Package general purpose:
  ====================================================================================================================== 
  These packages contains the needed files to be installed in order to support STM32H5 
  devices by EWARM9 and laters.

  We inform you that this package is suitable for internal & external use.
  EWARMv9_STM32H5xx_V1.1.2.exe has been digitally signed by STMicroelectronics.

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed:
  ================================================================ 
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
    - Product line with 2MB Flash size:STM32H563xI/H573xI/H562xI.
    - Product line with 1MB Flash size:STM32H563xG/H562xG.
	- Product line with 512KB Flash size:STM32H523xE/H533xE.
    - Product line with 256KB Flash size:STM32H523xC.
    - Product line with 128kB Flash size:STM32H503xB.
	
    - Automatic STM32H5 2M Internal Secure and Non-secure Flash algorithm selection.
    - Automatic STM32H5 1M Internal Secure and Non-secure Flash algorithm selection.
	- Automatic STM32H5 512KB Internal Secure and Non-secure Flash algorithm selection.
    - Automatic STM32H5 256KB Internal Secure and Non-secure Flash algorithm selection.
    - Automatic STM32H5 128K Internal Non-secure Flash algorithm selection.
	
    - STM32H573I-DK dedicated connection with OSPI external loader support.
    - files (.mac, .boards, .flash) for secure flashloader when life state code in TZ-Clozed or iROT-provisioned.
    
	3. The following SVD files will be added:
	- STM32H573, STM32H563, STM32H562 & STM32H503 SVD files v1r2.
	- STM32H523 & STM32H533 SVD file v0r1.
  

PS: When using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.
    That you can run EWARMv9_STM32H5xx_V1.1.2.exe only if the uninstall is not needed.

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32H5xx_V1.1.2.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   

 * When the device is in TZ-closed or iROT-provisioned life state, It's recommended to use FlashSTM32H5_SEC.board as flashloader:
	-Go to "Options->Debugger->Download".
	-Check "Override default .board file".
	-Browse and select "FlashSTM32H5_SEC.board" under "IAR_INSTALL_FOLDER->arm->config->flashloader->ST".

PS: Please make sure to use the highest frequency while using the macro-flashloader to have a better performance.
	
Known Limitation:
================
 * When the device is in TZ-closed or iROT-provisioned life state, You can debug only with software reset. 

 SVD files ReleaseNotes:
 =======================
	=======================================================
	V1.0   First release: adding support to STM32H5 devices (2M & 128K)
    =======================================================
    V1.1   Clean up & Adding support for I2C3/I2C4
	=======================================================
    V1.2   Update support for GTZC1_TZSC registers for STM32H562/63/73
	
	=======================================================
	STM32H523_v0r1:    initial release
	=======================================================
	Doc ID: RM0510 - Rev 0.2 - 25 September 2023
	First release based on IPxact delivery
	(derived from STM32H5-2M) without PKA/AES/SAES
		
	=======================================================
	STM32H533_v0r1:    initial release
	=======================================================
	Doc ID: RM0510 - Rev 0.2 - 25 September 2023
	First release based on IPxact delivery
	(derived from STM32H5-2M) with PKA/AES/SAES
	



